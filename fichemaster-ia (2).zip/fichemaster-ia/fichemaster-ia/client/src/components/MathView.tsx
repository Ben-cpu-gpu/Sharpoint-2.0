import { useEffect, useRef } from "react";
import katex from "katex";
import "katex/dist/katex.min.css";

export default function MathView({ value, focus = false, masked = false }: { value: string; focus?: boolean; masked?: boolean }) {
  const ref = useRef<HTMLSpanElement>(null);
  useEffect(() => {
    if (!ref.current) return;
    if (masked) { ref.current.textContent = "▰▰▰ formule masquée ▰▰▰"; return; }
    try {
      const normalized = value.replace(/\$\$([\s\S]+?)\$\$/g, "$1").replace(/\$([^$]+)\$/g, "$1");
      katex.render(normalized, ref.current, { throwOnError: false, strict: "ignore", trust: false, displayMode: false });
    } catch { ref.current.textContent = value; }
  }, [value, masked]);
  return <span ref={ref} className={focus ? "math-focus" : ""} />;
}
