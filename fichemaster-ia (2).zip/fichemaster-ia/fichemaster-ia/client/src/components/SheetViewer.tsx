import { useState } from "react";
import { Eye, EyeOff, Focus } from "lucide-react";
import type { StudySheet } from "../types/course";
import MathView from "./MathView";

export default function SheetViewer({ sheet }: { sheet: StudySheet }) {
  const [focus, setFocus] = useState(false); const [recall, setRecall] = useState(false);
  return <div className="stack">
    <div className="page-title"><div><span className="eyebrow">{sheet.chapter} · {sheet.tags.join(" / ")}</span><h1>{sheet.title}</h1><p>{sheet.subtitle}</p></div>
      <div className="actions"><button className={`btn secondary ${focus ? "selected" : ""}`} onClick={() => setFocus(!focus)}><Focus size={16}/> Focus LaTeX</button><button className={`btn secondary ${recall ? "selected" : ""}`} onClick={() => setRecall(!recall)}>{recall ? <Eye size={16}/> : <EyeOff size={16}/>} Active Recall</button></div></div>
    <section className="panel"><h2>Théorèmes & propriétés</h2>{sheet.theorems.map(t => <article className="content-item" key={t.id}><h3>{t.name}</h3><div className="math-block"><MathView value={t.statement} focus={focus} masked={recall}/></div>{t.strictConditions.length > 0 && <p><b>Conditions :</b> {t.strictConditions.join(" · ")}</p>}<p className="tip">Conseil prof : {t.professorTip}</p></article>)}</section>
    <section className="panel"><h2>Formules à connaître</h2><div className="formula-grid">{sheet.magicFormulas.map(f => <article className="formula-card" key={f.id}><b>{f.name}</b><div className="math-block"><MathView value={f.formula} focus={focus} masked={recall}/></div><p>{f.unitsAndVariables}</p><small>Domaine : {f.validityDomain}</small></article>)}</div></section>
    <section className="panel"><h2>Méthodes pas à pas</h2>{sheet.stepByStepMethods.map(m => <article className="content-item" key={m.id}><h3>{m.goal}</h3><ol>{m.steps.map((s,i)=><li key={i}>{s}</li>)}</ol><p className="warning">Piège à éviter : {m.trapToAvoid}</p></article>)}</section>
    <section className="panel"><h2>Pièges classiques</h2><ul>{sheet.examTraps.map((t,i)=><li key={i}>{t}</li>)}</ul></section>
    <section className="panel"><h2>Flashcards</h2>{sheet.flashcards.map((f,i)=><details className="flashcard" key={i}><summary>{f.question}</summary><p>{f.answer}</p></details>)}</section>
    <section className="panel"><h2>Auto-évaluation</h2>{sheet.quiz.map((q,i)=><details className="flashcard" key={i}><summary>{q.question}</summary><ol>{q.options.map((o,j)=><li key={j}>{o}</li>)}</ol><p><b>Réponse :</b> {q.options[q.correctIndex]}. {q.explanation}</p></details>)}</section>
  </div>;
}
