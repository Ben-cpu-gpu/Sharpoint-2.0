import { useEffect, useMemo, useState } from "react";
import { Clock3, Play, Square } from "lucide-react";
import type { AnnaleItem } from "../types/course";

export default function AnnalesSection({ items }: { items: AnnaleItem[] }) {
  const [year,setYear]=useState("all");const [session,setSession]=useState("all");const [active,setActive]=useState<AnnaleItem|null>(null);const [seconds,setSeconds]=useState(0);
  const years=[...new Set(items.map(x=>x.year))].sort((a,b)=>b-a);const sessions=[...new Set(items.map(x=>x.session))];
  const filtered=useMemo(()=>items.filter(x=>(year==="all"||String(x.year)===year)&&(session==="all"||x.session===session)),[items,year,session]);
  useEffect(()=>{if(!active)return;const timer=window.setInterval(()=>setSeconds(s=>Math.max(0,s-1)),1000);return()=>window.clearInterval(timer)},[active]);
  function start(item:AnnaleItem){setActive(item);setSeconds(item.durationMinutes*60)}
  const fmt=(n:number)=>`${String(Math.floor(n/60)).padStart(2,"0")}:${String(n%60).padStart(2,"0")}`;
  return <div className="stack"><div className="page-title"><div><span className="eyebrow">SUJETS D'EXAMEN</span><h1>Annales</h1><p>Entraînez-vous en conditions réelles.</p></div></div>
    <div className="filters"><select className="input" value={year} onChange={e=>setYear(e.target.value)}><option value="all">Toutes les années</option>{years.map(y=><option key={y}>{y}</option>)}</select><select className="input" value={session} onChange={e=>setSession(e.target.value)}><option value="all">Toutes les sessions</option>{sessions.map(s=><option key={s}>{s}</option>)}</select></div>
    {filtered.map(a=><article className="panel" key={a.id}><div className="annale-head"><div><span className="eyebrow">{a.year} · {a.session}</span><h3>{a.title}</h3><p className="muted">{a.chapter} · {a.points} points · {a.durationMinutes} min</p></div><button className="btn" onClick={()=>start(a)}><Play size={16}/> Mode Examen</button></div><details><summary>Énoncé & barème</summary><p className="preline">{a.statement}</p><h4>Barème</h4><ul>{a.gradingCriteria.map((g,i)=><li key={i}>{g}</li>)}</ul><details><summary>Correction détaillée</summary><p className="preline">{a.solution}</p></details></details></article>)}
    {active&&<div className="timer"><div><span className="eyebrow">MODE EXAMEN · {active.title}</span><strong className={seconds<300?"urgent":""}>{fmt(seconds)}</strong></div><button className="icon-btn" onClick={()=>setActive(null)} title="Arrêter"><Square size={18}/></button>{seconds===0&&<span className="error">Temps écoulé</span>}</div>}
  </div>;
}
