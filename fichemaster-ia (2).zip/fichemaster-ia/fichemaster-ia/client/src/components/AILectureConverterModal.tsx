import { useState } from "react";
import { AlertTriangle, FileUp, LoaderCircle, Sparkles } from "lucide-react";
import { ApiError, api } from "../lib/api";
import type { StudySheet } from "../types/course";

export default function AILectureConverterModal({ onClose, onImported }: { onClose: () => void; onImported: (s: StudySheet) => void }) {
  const [text, setText] = useState(""); const [fileName, setFileName] = useState("");
  const [loading, setLoading] = useState(false); const [consent, setConsent] = useState(false); const [error, setError] = useState("");
  async function convert(forceLocal = false) {
    setLoading(true); setError(""); setConsent(false);
    try {
      const result = await api<StudySheet>("/api/gemini/transform-lecture-to-toolbox", { text, forceLocal });
      onImported(result); onClose();
    } catch (e) {
      if (e instanceof ApiError && e.code === "REQUIRE_USER_CONSENT") setConsent(true);
      else setError(e instanceof Error ? e.message : "Erreur inconnue.");
    } finally { setLoading(false); }
  }
  async function readFile(file?: File) {
    if (!file) return; setFileName(file.name);
    if (file.type === "application/pdf") {
      const form = new FormData(); form.append("file", file);
      setLoading(true);
      try {
        const response = await fetch("/api/documents/pdf-text", { method: "POST", body: form });
        const data = await response.json(); if (!response.ok) throw new Error(data.message || "Lecture PDF impossible.");
        setText(data.text);
      } catch (e) { setError(e instanceof Error ? e.message : "Erreur PDF."); }
      finally { setLoading(false); }
    } else setText(await file.text());
  }
  return <div className="overlay"><section className="modal">
    <div className="modal-head"><div><span className="eyebrow">IMPORT INTELLIGENT</span><h2>Transformer un cours</h2></div><button className="icon-btn" onClick={onClose}>✕</button></div>
    <label className="dropzone"><FileUp size={24}/><b>{fileName || "Déposez un PDF ou un fichier texte"}</b><span>ou cliquez pour parcourir</span><input type="file" accept=".pdf,.txt,.md" onChange={e => readFile(e.target.files?.[0])}/></label>
    <textarea className="textarea" rows={8} placeholder="Vous pouvez aussi coller directement le contenu du cours…" value={text} onChange={e => setText(e.target.value)}/>
    {error && <p className="error">{error}</p>}
    {consent && <div className="consent"><AlertTriangle size={20}/><div><b>Les intelligences artificielles sont temporairement surchargées.</b><p>Voulez-vous que l'application tente d'extraire les éléments localement (Mode Brouillon) ?</p><div className="actions"><button className="btn secondary" onClick={() => convert(false)}>Réessayer l'IA</button><button className="btn" onClick={() => convert(true)}>Forcer le mode brouillon</button></div></div></div>}
    <div className="modal-actions"><button className="btn secondary" onClick={onClose}>Annuler</button><button className="btn" disabled={!text.trim() || loading} onClick={() => convert(false)}>{loading ? <LoaderCircle className="spin" size={16}/> : <Sparkles size={16}/>} Générer ma fiche</button></div>
  </section></div>;
}
