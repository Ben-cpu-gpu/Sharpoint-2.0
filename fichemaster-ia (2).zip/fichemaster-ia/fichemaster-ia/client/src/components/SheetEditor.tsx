import { useState } from "react";
import { Plus, Save } from "lucide-react";
import { api } from "../lib/api";
import type { StudySheet } from "../types/course";

export default function SheetEditor({ sheet, onSave }: { sheet: StudySheet; onSave: (s: StudySheet) => void }) {
  const [draft, setDraft] = useState(sheet); const [prompt, setPrompt] = useState(""); const [loading, setLoading] = useState(false); const [error, setError] = useState("");
  async function addViaAI() {
    setLoading(true); setError("");
    try { const notion = await api<any>("/api/gemini/generate-notion", { prompt, type: "theorem", context: draft.title });
      setDraft(s => ({ ...s, theorems: [...s.theorems, { id: notion.id || crypto.randomUUID(), name: notion.name || prompt, statement: notion.statement || "", strictConditions: notion.strictConditions || [], professorTip: notion.professorTip || "" }] }));
      setPrompt("");
    } catch(e) { setError(e instanceof Error ? e.message : "Erreur IA."); } finally { setLoading(false); }
  }
  return <div className="panel stack"><h2>Modifier la fiche</h2><label>Titre<input className="input" value={draft.title} onChange={e=>setDraft({...draft,title:e.target.value})}/></label><label>Chapitre<input className="input" value={draft.chapter} onChange={e=>setDraft({...draft,chapter:e.target.value})}/></label>
    <label>Sous-titre<input className="input" value={draft.subtitle} onChange={e=>setDraft({...draft,subtitle:e.target.value})}/></label>
    <div className="divider"/><h3>Ajouter une notion avec l'IA</h3><div className="inline-form"><input className="input" placeholder="Ex. Théorème de Bernoulli…" value={prompt} onChange={e=>setPrompt(e.target.value)}/><button className="btn" disabled={!prompt.trim()||loading} onClick={addViaAI}><Plus size={16}/> via IA</button></div>{error&&<p className="error">{error}</p>}
    <button className="btn" onClick={()=>onSave(draft)}><Save size={16}/> Enregistrer</button>
  </div>;
}
