import { useEffect, useMemo, useState } from "react";
import { BookOpen, BrainCircuit, ClipboardList, FilePlus2, GraduationCap, Moon, Sun, PanelLeftClose, PanelLeftOpen, Search } from "lucide-react";
import { motion } from "framer-motion";
import type { AnnaleItem, StudySheet, TDExercise } from "./types/course";
import AILectureConverterModal from "./components/AILectureConverterModal";
import SheetViewer from "./components/SheetViewer";
import SheetEditor from "./components/SheetEditor";
import TDSection from "./components/TDSection";
import AnnalesSection from "./components/AnnalesSection";

type Tab="sheets"|"td"|"annales";
const demoSheet:StudySheet={id:"demo-sheet",subjectId:"maths",title:"Analyse — Fonctions et dérivées",subtitle:"Les fondamentaux à maîtriser",chapter:"Analyse",tags:["Analyse","Dérivation"],mastery:"learning",
theorems:[{id:"t1",name:"Théorème de Rolle",statement:"f(a)=f(b) \\Rightarrow \\exists c\\in]a,b[,\\ f'(c)=0",strictConditions:["f continue sur [a,b]","f dérivable sur ]a,b[","f(a)=f(b)"],professorTip:"Vérifiez toujours les hypothèses avant d'appliquer le théorème."}],
magicFormulas:[{id:"f1",name:"Dérivée d'un produit",formula:"(uv)'=u'v+uv'",unitsAndVariables:"u et v sont dérivables.",validityDomain:"Sur tout intervalle où u et v sont dérivables."}],
stepByStepMethods:[{id:"m1",goal:"Étudier les variations d'une fonction",steps:["Déterminer l'ensemble de définition.","Calculer la dérivée f'.","Étudier le signe de f'.","Construire le tableau de variations."],trapToAvoid:"Ne pas oublier les points où la dérivée n'existe pas."}],
examTraps:["Confondre continuité et dérivabilité.","Appliquer un théorème sans vérifier toutes ses hypothèses."],flashcards:[{question:"Quelle condition garantit le théorème de Rolle ?",answer:"Continuité sur [a,b], dérivabilité sur ]a,b[ et égalité des valeurs aux bornes."}],quiz:[]};
const demoTD:TDExercise[]=[{id:"td1",subjectId:"maths",chapter:"Analyse",title:"Étude d'une fonction polynomiale",notion:"Dérivation",difficulty:1,statement:"Soit f(x)=x³−3x²+2. Étudier les variations de f sur ℝ.",hints:["Commencez par calculer f'(x).","Factorisez la dérivée pour étudier son signe."],solution:"f'(x)=3x²−6x=3x(x−2). Le signe est positif sur ]−∞,0[, négatif sur ]0,2[, positif sur ]2,+∞[. La fonction croît, décroît puis croît.",status:"todo"}];
const demoAnnale:AnnaleItem[]=[{...demoTD[0],id:"ann1",title:"Partiel d'analyse — exercice 1",year:2025,session:"Session 1",durationMinutes:90,points:8,gradingCriteria:["Calcul de la dérivée : 2 pts","Étude du signe : 3 pts","Tableau de variations : 3 pts"]}];

export default function App(){
  const [tab,setTab]=useState<Tab>("sheets");const [sheets,setSheets]=useState<StudySheet[]>(()=>JSON.parse(localStorage.getItem("fm-sheets")||"null")||[demoSheet]);
  const [td,setTd]=useState<TDExercise[]>(()=>JSON.parse(localStorage.getItem("fm-td")||"null")||demoTD);
  const [annales]=useState<AnnaleItem[]>(()=>JSON.parse(localStorage.getItem("fm-annales")||"null")||demoAnnale);
  const [selected,setSelected]=useState(sheets[0]?.id||"");const [modal,setModal]=useState(false);const [editing,setEditing]=useState(false);const [dark,setDark]=useState(true);const [collapsed,setCollapsed]=useState(false);const [query,setQuery]=useState("");
  useEffect(()=>localStorage.setItem("fm-sheets",JSON.stringify(sheets)),[sheets]);useEffect(()=>localStorage.setItem("fm-td",JSON.stringify(td)),[td]);useEffect(()=>localStorage.setItem("fm-annales",JSON.stringify(annales)),[annales]);
  useEffect(()=>{document.documentElement.classList.toggle("light",!dark)},[dark]);
  const current=sheets.find(s=>s.id===selected)||sheets[0];
  const visibleSheets=useMemo(()=>sheets.filter(s=>s.title.toLowerCase().includes(query.toLowerCase())),[sheets,query]);
  function importSheet(sheet:StudySheet){setSheets(prev=>[sheet,...prev]);setSelected(sheet.id);setTab("sheets");setEditing(false)}
  return <div className={`app-shell ${collapsed?"sidebar-collapsed":""}`}>
    <aside className="sidebar"><div className="brand"><div className="brand-icon"><BrainCircuit size={22}/></div>{!collapsed&&<div><b>FicheMaster <span>IA</span></b><small>Votre copilote de révision</small></div>}</div>
      <div className="nav-label">{!collapsed&&"ESPACE DE TRAVAIL"}</div>
      <button className={`nav-item ${tab==="sheets"?"active":""}`} onClick={()=>setTab("sheets")}><BookOpen size={18}/>{!collapsed&&"Fiches de cours"}</button>
      <button className={`nav-item ${tab==="td"?"active":""}`} onClick={()=>setTab("td")}><ClipboardList size={18}/>{!collapsed&&"Exercices & TD"}</button>
      <button className={`nav-item ${tab==="annales"?"active":""}`} onClick={()=>setTab("annales")}><GraduationCap size={18}/>{!collapsed&&"Annales"}</button>
      {tab==="sheets"&&!collapsed&&<><div className="nav-label list-label">MES FICHES <span>{sheets.length}</span></div><div className="sheet-search"><Search size={14}/><input placeholder="Rechercher…" value={query} onChange={e=>setQuery(e.target.value)}/></div><div className="sheet-list">{visibleSheets.map(s=><button key={s.id} className={`sheet-link ${selected===s.id?"chosen":""}`} onClick={()=>{setSelected(s.id);setEditing(false)}}><span className="dot"/><span>{s.title}</span></button>)}</div></>}
      <div className="sidebar-bottom"><button className="nav-item" onClick={()=>setDark(!dark)}>{dark?<Sun size={18}/>:<Moon size={18}/ >}{!collapsed&&(dark?"Mode clair":"Mode sombre")}</button><button className="nav-item" onClick={()=>setCollapsed(!collapsed)}>{collapsed?<PanelLeftOpen size={18}/>:<PanelLeftClose size={18}/ >}{!collapsed&&"Réduire"}</button></div>
    </aside>
    <main className="main-area"><header className="topbar"><div className="breadcrumb">Workspace <span>/</span> {tab==="sheets"?"Fiches de cours":tab==="td"?"Exercices & TD":"Annales"}</div><button className="btn" onClick={()=>setModal(true)}><FilePlus2 size={16}/> Importer un cours</button></header>
      <motion.div key={tab+(editing?"edit":"view")} initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} transition={{duration:.2}} className="main-content">
        {tab==="sheets"&&current&&<>{editing?<SheetEditor sheet={current} onSave={s=>{setSheets(prev=>prev.map(x=>x.id===s.id?s:x));setEditing(false)}}/>:<><div className="toolbar"><span className="pill">FICHE ACTIVE</span><button className="btn secondary" onClick={()=>setEditing(true)}>Modifier la fiche</button></div><SheetViewer sheet={current}/></>}</>}
        {tab==="sheets"&&!current&&<div className="empty"><BookOpen/><h2>Aucune fiche pour le moment</h2><p>Importez un cours pour créer votre première fiche.</p><button className="btn" onClick={()=>setModal(true)}>Importer un cours</button></div>}
        {tab==="td"&&<TDSection exercises={td} onChange={setTd}/>}
        {tab==="annales"&&<AnnalesSection items={annales}/>}
      </motion.div>
    </main>
    {modal&&<AILectureConverterModal onClose={()=>setModal(false)} onImported={importSheet}/>}
  </div>;
}
