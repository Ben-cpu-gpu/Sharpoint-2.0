export type Mastery = "to_learn" | "learning" | "mastered";
export type ExerciseStatus = "todo" | "in_progress" | "completed";

export interface Theorem {
  id: string; name: string; statement: string; strictConditions: string[]; professorTip: string;
}
export interface MagicFormula {
  id: string; name: string; formula: string; unitsAndVariables: string; validityDomain: string;
}
export interface StepByStepMethod {
  id: string; goal: string; steps: string[]; trapToAvoid: string;
}
export interface Flashcard { question: string; answer: string; }
export interface QuizQuestion { question: string; options: [string, string, string, string]; correctIndex: number; explanation: string; }

export interface StudySheet {
  id: string; subjectId: string; title: string; subtitle: string; chapter: string; tags: string[];
  mastery: Mastery; theorems: Theorem[]; magicFormulas: MagicFormula[];
  stepByStepMethods: StepByStepMethod[]; examTraps: string[]; flashcards: Flashcard[]; quiz: QuizQuestion[];
}

export interface TDExercise {
  id: string; subjectId: string; chapter: string; title: string; notion: string;
  difficulty: 1 | 2 | 3; statement: string; hints: string[]; solution: string; status: ExerciseStatus;
}
export interface AnnaleItem extends TDExercise {
  session: string; year: number; durationMinutes: number; points: number; gradingCriteria: string[];
}
