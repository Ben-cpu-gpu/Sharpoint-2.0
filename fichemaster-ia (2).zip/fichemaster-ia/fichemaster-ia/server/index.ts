import "dotenv/config";
import express, { Request, Response, NextFunction } from "express";
import cors from "cors";
import multer from "multer";
import { GoogleGenAI } from "@google/genai";
import pdf from "pdf-parse";
import { z } from "zod";
import path from "node:path";
import { fileURLToPath } from "node:url";

const app = express();
const port = Number(process.env.PORT || 3001);
app.use(cors({ origin: process.env.CLIENT_ORIGIN || "http://localhost:5173" }));
app.use(express.json({ limit: "25mb" }));
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20 * 1024 * 1024 } });

type JsonRecord = Record<string, unknown>;
const ConsentError = { error: "REQUIRE_USER_CONSENT", message: "Les serveurs IA sont inaccessibles." };

function cleanJson(raw: string): unknown {
  const cleaned = raw.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start < 0 || end < start) throw new Error("La réponse IA ne contient pas de JSON valide.");
  return JSON.parse(cleaned.slice(start, end + 1));
}

async function askGemini(prompt: string): Promise<unknown> {
  if (!process.env.GEMINI_API_KEY) throw new Error("GEMINI_API_KEY manquante");
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  const result = await ai.models.generateContent({
    model: "gemini-3.1-pro",
    contents: prompt,
    config: { responseMimeType: "application/json", temperature: 0.25 }
  });
  return cleanJson(result.text || "");
}

async function askGroq(prompt: string): Promise<unknown> {
  if (!process.env.GROQ_API_KEY) throw new Error("GROQ_API_KEY manquante");
  const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: { Authorization: `Bearer ${process.env.GROQ_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "openai/gpt-oss-120b",
      temperature: 0.25,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: "Tu es un assistant pédagogique. Réponds uniquement avec un objet JSON valide, sans Markdown ni balises." },
        { role: "user", content: prompt }
      ]
    })
  });
  if (!response.ok) throw new Error(`Groq HTTP ${response.status}: ${await response.text()}`);
  const payload = await response.json() as any;
  return cleanJson(payload.choices?.[0]?.message?.content || "");
}

async function withAI(prompt: string, forceLocal: boolean, local: () => unknown) {
  try { return await askGemini(prompt); }
  catch (geminiError) {
    console.warn("Gemini indisponible:", geminiError);
    try { return await askGroq(prompt); }
    catch (groqError) {
      console.warn("Groq indisponible:", groqError);
      if (forceLocal) return local();
      const error = new Error(ConsentError.message) as Error & { status?: number; code?: string };
      error.status = 503; error.code = ConsentError.error; throw error;
    }
  }
}

function extractText(req: Request): string {
  const body = req.body as JsonRecord;
  const text = typeof body.text === "string" ? body.text : "";
  if (text.trim()) return text;
  const base64 = typeof body.fileBase64 === "string" ? body.fileBase64 : "";
  if (base64) return Buffer.from(base64.replace(/^data:.*?;base64,/, ""), "base64").toString("utf8");
  return "";
}

function localSheet(text: string, subjectId = "general"): JsonRecord {
  const lines = text.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
  const formulas = [...text.matchAll(/(?:^|\n)\s*([^=\n]{2,70})\s*=\s*([^\n]{2,120})/g)].slice(0, 12);
  const theoremLines = lines.filter(l => /\b(théorème|theoreme|proposition|lemme|corollaire)\b/i.test(l)).slice(0, 10);
  return {
    id: crypto.randomUUID(), subjectId, title: lines[0]?.slice(0, 90) || "Fiche importée",
    subtitle: "Brouillon généré localement", chapter: "À classer", tags: ["brouillon"],
    mastery: "to_learn",
    theorems: theoremLines.map((name, i) => ({ id: `th-${i}`, name, statement: name, strictConditions: [], professorTip: "À compléter et vérifier." })),
    magicFormulas: formulas.map((m, i) => ({ id: `f-${i}`, name: m[1].trim(), formula: m[0].trim(), unitsAndVariables: "À compléter", validityDomain: "À vérifier" })),
    stepByStepMethods: [], examTraps: ["Brouillon local : vérifier chaque résultat avec le cours."], flashcards: [], quiz: []
  };
}

const sheetSchema = z.object({ text: z.string().optional(), fileBase64: z.string().optional(), subjectId: z.string().optional(), forceLocal: z.boolean().optional() });
app.post("/api/gemini/transform-lecture-to-toolbox", async (req, res, next) => {
  try {
    const input = sheetSchema.parse(req.body);
    const text = extractText(req);
    if (!text.trim()) return res.status(400).json({ error: "EMPTY_DOCUMENT", message: "Aucun texte exploitable fourni." });
    const prompt = `Transforme ce cours en fiche de révision structurée. Retourne uniquement un JSON conforme à ce schéma : {id,subjectId,title,subtitle,chapter,tags,mastery,theorems:[{id,name,statement,strictConditions,professorTip}],magicFormulas:[{id,name,formula,unitsAndVariables,validityDomain}],stepByStepMethods:[{id,goal,steps,trapToAvoid}],examTraps,flashcards:[{question,answer}],quiz:[{question,options,correctIndex,explanation}]}. Les formules doivent être en LaTeX. N'invente pas de contenu absent. Cours :\n${text}`;
    const result = await withAI(prompt, !!input.forceLocal, () => localSheet(text, input.subjectId));
    res.json(result);
  } catch (e) { next(e); }
});

app.post("/api/gemini/parse-td-document", async (req, res, next) => {
  try {
    const text = extractText(req);
    if (!text.trim()) return res.status(400).json({ error: "EMPTY_DOCUMENT", message: "Document vide." });
    const prompt = `Découpe le document en exercices indépendants. Pour CHAQUE exercice, génère des hints et une solution détaillée, sans inventer de données. JSON uniquement : {exercises:[{id,subjectId,chapter,title,notion,difficulty,statement,hints,solution,status}]}. Document:\n${text}`;
    const result = await withAI(prompt, !!req.body.forceLocal, () => ({
      exercises: text.split(/(?=Exercice\s*\d+)/i).filter(s => s.trim()).map((statement, i) => ({
        id: crypto.randomUUID(), subjectId: "general", chapter: "À classer", title: `Exercice ${i + 1}`,
        notion: "À identifier", difficulty: 1, statement, hints: ["Repérer les données et la notion mobilisée."],
        solution: "Correction indisponible en mode brouillon. Demandez une correction IA lorsque les services seront accessibles.",
        status: "todo"
      }))
    }));
    res.json(result);
  } catch (e) { next(e); }
});

app.post("/api/gemini/generate-similar-exercise", async (req, res, next) => {
  try {
    const exercise = req.body.exercise as JsonRecord;
    if (!exercise) return res.status(400).json({ error: "MISSING_EXERCISE" });
    const prompt = `Génère une variante d'entraînement du même niveau et de la même notion, avec valeurs différentes, énoncé, hints et correction détaillée. JSON uniquement avec les champs id,subjectId,chapter,title,notion,difficulty,statement,hints,solution,status. Exercice source: ${JSON.stringify(exercise)}`;
    const result = await withAI(prompt, !!req.body.forceLocal, () => ({
      ...exercise, id: crypto.randomUUID(), title: `${String(exercise.title || "Exercice")} — variante brouillon`,
      statement: `${String(exercise.statement || "")}\n\n[Variante locale non générée : réessayez lorsque les IA seront disponibles.]`,
      hints: ["Reprenez la méthode de l'exercice source."],
      solution: "Une nouvelle correction ne peut pas être produite hors ligne.", status: "todo"
    }));
    res.json(result);
  } catch (e) { next(e); }
});

app.post("/api/gemini/generate-notion", async (req, res, next) => {
  try {
    const { prompt, type, context, forceLocal } = req.body;
    if (!prompt || typeof prompt !== "string") return res.status(400).json({ error: "MISSING_PROMPT" });
    const instruction = `Crée une notion pédagogique de type ${type || "notion"} au format JSON. Champs selon le type : theorem {id,name,statement,strictConditions,professorTip}; formula {id,name,formula,unitsAndVariables,validityDomain}; method {id,goal,steps,trapToAvoid}. JSON uniquement. Contexte: ${context || ""}. Demande: ${prompt}`;
    const result = await withAI(instruction, !!forceLocal, () => ({
      id: crypto.randomUUID(), name: prompt, statement: "Contenu à compléter : génération locale indisponible.",
      strictConditions: [], professorTip: "À vérifier avec le cours."
    }));
    res.json(result);
  } catch (e) { next(e); }
});

app.post("/api/gemini/generate-quiz", async (req, res, next) => {
  try {
    const { sheet, forceLocal } = req.body;
    if (!sheet) return res.status(400).json({ error: "MISSING_SHEET" });
    const prompt = `Génère exactement 4 QCM distincts fondés uniquement sur cette fiche. Chaque question a exactement 4 options, correctIndex entre 0 et 3 et une explication. JSON uniquement : {quiz:[{question,options,correctIndex,explanation}]}. Fiche: ${JSON.stringify(sheet)}`;
    const result = await withAI(prompt, !!forceLocal, () => ({ quiz: (sheet.theorems || []).slice(0, 4).map((t: any) => ({
      question: `À vérifier : ${t.name}`, options: ["Option à compléter", "Option à compléter", "Option à compléter", "Option à compléter"],
      correctIndex: 0, explanation: "QCM brouillon : complétez les propositions avec le cours."
    })) }));
    res.json(result);
  } catch (e) { next(e); }
});

// Multipart PDF endpoint convenience: extracts text then delegates to the same transformation flow.
app.post("/api/documents/pdf-text", upload.single("file"), async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ error: "MISSING_FILE" });
    const parsed = await pdf(req.file.buffer);
    res.json({ text: parsed.text });
  } catch (e) { next(e); }
});

const here = path.dirname(fileURLToPath(import.meta.url));
app.use(express.static(path.resolve(here, "../../client/dist")));
app.get("*", (_req, res) => res.sendFile(path.resolve(here, "../../client/dist/index.html")));

app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
  console.error(err);
  if (err?.name === "ZodError") return res.status(400).json({ error: "INVALID_REQUEST", details: err.issues });
  if (err?.code === ConsentError.error) return res.status(503).json(ConsentError);
  res.status(err?.status || 500).json({ error: "INTERNAL_ERROR", message: "Une erreur inattendue est survenue." });
});

app.listen(port, () => console.log(`FicheMaster API disponible sur http://localhost:${port}`));
