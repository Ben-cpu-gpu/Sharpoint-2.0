# FicheMaster IA

Monorepo React 19 + Vite + Tailwind CSS v4 et API Express/TypeScript.

## Prérequis
- Node.js 20+
- npm 10+

## Installation
```bash
cp .env.example .env
# Renseignez GEMINI_API_KEY et GROQ_API_KEY dans .env (serveur uniquement)
npm install
npm run dev
```
Frontend : http://localhost:5173  
API : http://localhost:3001

## Build & production
```bash
npm run build
npm start
```

## Sécurité des clés
Les clés API doivent rester dans `.env` à la racine, ne jamais être préfixées par `VITE_`, et ne jamais être commitées. Les clés partagées dans une conversation ou un dépôt doivent être révoquées puis renouvelées.

## Routes
- `POST /api/gemini/transform-lecture-to-toolbox`
- `POST /api/gemini/parse-td-document`
- `POST /api/gemini/generate-similar-exercise`
- `POST /api/gemini/generate-notion`
- `POST /api/gemini/generate-quiz`
- `POST /api/documents/pdf-text` (extraction PDF multipart)

Toutes les routes IA tentent Gemini puis Groq. Si les deux échouent, réponse 503 `REQUIRE_USER_CONSENT`, sauf si `forceLocal: true` a été explicitement envoyé. Le mode local est un brouillon heuristique, jamais une correction fiable.

## Formats d'entrée
Les routes de transformation acceptent `text` ou `fileBase64` (PDF : utiliser de préférence `/api/documents/pdf-text` pour obtenir le texte extrait), ainsi que `forceLocal`.

## Limites de cette première version
- Les fiches, TD et annales sont persistés dans le `localStorage` du navigateur.
- L'éditeur manuel expose les champs principaux de fiche et l'ajout de théorème par IA ; une édition exhaustive de chaque sous-objet peut être ajoutée ensuite.
- Le parser local de PDF est volontairement séparé de la conversion IA. Il extrait le texte via `pdf-parse`, puis le frontend transmet le texte extrait.
- Les exercices créés en mode brouillon n'ont pas de correction mathématique fiable.
